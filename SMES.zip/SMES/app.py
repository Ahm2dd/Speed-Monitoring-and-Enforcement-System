from flask import Flask, render_template, request
import cv2
import dlib
import time
from datetime import datetime
import os
import glob
import numpy as np
import imutils
import pytesseract
from flask import Flask, render_template, request, redirect, url_for, session , abort


app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this to a secure secret key
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default_secret_key')

# Dummy user credentials (replace with your actual user authentication logic)
valid_users = {'a': 'a', 'b': 'b'}
class LicensePlateDetector:
    def __init__(self, cascade_path):
        self.license_cascade = cv2.CascadeClassifier(cascade_path)

    def detect_from_image(self, image_path):
        try:
            image = cv2.imread(image_path)
            if image is None:
                print(f"Error: Unable to read image '{image_path}'")
                return None

            gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            filter_ = cv2.bilateralFilter(gray_image, 11, 17, 17)
            edged = cv2.Canny(filter_, 30, 200)

            contours = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            contours = imutils.grab_contours(contours)
            contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]

            for contour in contours:
                approx = cv2.approxPolyDP(contour, 10, True)
                if len(approx) == 4:
                    plate_contour = approx
                    break

            mask = np.zeros(gray_image.shape, dtype=np.uint8)
            cv2.drawContours(mask, [plate_contour], -1, (255, 255, 255), -1)
            masked_image = cv2.bitwise_and(image, image, mask=mask)

            (x, y, w, h) = cv2.boundingRect(plate_contour)
            plate_image = masked_image[y:y+h, x:x+w]

            # Convert plate image to grayscale for OCR
            plate_gray = cv2.cvtColor(plate_image, cv2.COLOR_BGR2GRAY)

            # Use Tesseract for OCR
            custom_config = r'--oem 3 --psm 6'  # OCR engine mode (OEM) and page segmentation mode (PSM)
            plate_text = pytesseract.image_to_string(plate_gray, config=custom_config)

            return plate_text

        except Exception as e:
            print(f"Error processing image '{image_path}': {str(e)}")
            return None

def trackCars(linkVideo, speedLimit):
    carCascade = cv2.CascadeClassifier('cars.xml')
    app = Flask(__name__)

    if linkVideo == '0':
        linkVideo = 0 
    else:
        linkVideo = 'videos/' + linkVideo + '.mp4'

    if linkVideo != 0 and not os.path.exists(linkVideo):
        print(linkVideo + ' file not exist')
        return

    speedLimit = int(speedLimit)  # Ensure speedLimit is an integer


    video = cv2.VideoCapture(linkVideo)
    print('Speed Limit Set at {} Kmph'.format(speedLimit))

    WIDTH = 1280 
    HEIGHT = 720 
    cropBegin = 240 
    mark1 = 120 
    mark2 = 360 
    fpsFactor = 3
    markGap = 15 
    startTracker = {} 
    endTracker = {} 
    speedLimit = int(speedLimit) 

    if not os.path.exists('overspeeding/'):
        os.makedirs('overspeeding/')
    else:
        files = glob.glob('overspeeding/*')
        for f in files:
            os.remove(f)

    print('Speed Limit Set at {} Kmph'. format(speedLimit))

    def blackout(image):
        xBlack = 360
        yBlack = 300
        triangle_cnt = np.array([[0,0], [xBlack,0], [0,yBlack]])
        triangle_cnt2 = np.array([[WIDTH,0], [WIDTH-xBlack,0], [WIDTH,yBlack]])
        cv2.drawContours(image, [triangle_cnt], 0, (0,0,0), -1)
        cv2.drawContours(image, [triangle_cnt2], 0, (0,0,0), -1)
        return image

    def saveCar(carId, speed, image):
        now = datetime.today().now()
        nameCurTime = now.strftime(")-%d-%m-%Y-%H-%M-%S-%f")
        link = f'overspeeding/car({carId})-speed({int(speed)}){nameCurTime}.png'
        cv2.imwrite(link, image)

    def estimateSpeed(carID):
        timeDiff = endTracker[carID] - startTracker[carID]
        speed = round(markGap / timeDiff * fpsFactor * 3.6, 2)
        return speed

    rectangleColor = (0, 255, 0)
    frameCounter = 0
    currentCarID = 0
    carTracker = {}

    while True:
        rc, image = video.read()
        if not rc:
            break

        frameTime = time.time()
        image = cv2.resize(image, (WIDTH, HEIGHT))[cropBegin:720, 0:1280]
        resultImage = blackout(image)
        cv2.line(resultImage, (0, mark1), (1280, mark1), (0, 0, 255), 2)
        cv2.line(resultImage, (0, mark2), (1280, mark2), (0, 0, 255), 2)

        frameCounter += 1
        carIDtoDelete = []

        # Update existing car trackers
        for carID in list(carTracker.keys()):
            trackingQuality = carTracker[carID].update(image)
            if trackingQuality < 7:
                carIDtoDelete.append(carID)

        # Remove inactive car trackers
        for carID in carIDtoDelete:
            carTracker.pop(carID)

        # Detect new cars every 60 frames
        if (frameCounter % 60 == 0):
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            cars = carCascade.detectMultiScale(gray, 1.1, 13, 18, (24, 24))

            for (_x, _y, _w, _h) in cars:
                x = int(_x)
                y = int(_y)
                w = int(_w)
                h = int(_h)
                xbar = x + 0.5 * w
                ybar = y + 0.5 * h
                matchCarID = None

                for carID in carTracker.keys():
                    trackedPosition = carTracker[carID].get_position()
                    tx = int(trackedPosition.left())
                    ty = int(trackedPosition.top())
                    tw = int(trackedPosition.width())
                    th = int(trackedPosition.height())
                    txbar = tx + 0.5 * tw
                    tybar = ty + 0.5 * th

                    if (tx <= xbar <= (tx + tw)) and (ty <= ybar <= (ty + th)) and (x <= txbar <= (x + w)) and (y <= tybar <= (y + h)):
                        matchCarID = carID

                if matchCarID is None:
                    tracker = dlib.correlation_tracker()
                    tracker.start_track(image, dlib.rectangle(x, y, x + w, y + h))
                    carTracker[currentCarID] = tracker
                    currentCarID += 1

        # Draw bounding boxes and track speeds
        for carID in carTracker.keys():
            trackedPosition = carTracker[carID].get_position()
            tx = int(trackedPosition.left())
            ty = int(trackedPosition.top())
            tw = int(trackedPosition.width())
            th = int(trackedPosition.height())
            cv2.rectangle(resultImage, (tx, ty), (tx + tw, ty + th), rectangleColor, 2)
            cv2.putText(resultImage, str(carID), (tx, ty - 5), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 255, 0), 1)

            if carID not in startTracker and mark2 > ty + th > mark1 and ty < mark1:
                startTracker[carID] = frameTime
            elif carID in startTracker and carID not in endTracker and mark2 < (ty + th):
                endTracker[carID] = frameTime
                speed = estimateSpeed(carID)
                cv2.putText(resultImage, str(speed) + " kmph", (tx, ty - 5), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 255, 0), 1)

                if speed > speedLimit:
                    print(f'CAR-ID : {carID} : {speed} kmph - OVERSPEED')
                    saveCar(carID, speed, image[ty:ty + th, tx:tx + tw])
                else:
                    print(f'CAR-ID : {carID} : {speed} kmph')

        cv2.imshow('result', resultImage)

        if cv2.waitKey(33) == 27:
            break

    video.release()
    cv2.destroyAllWindows()

    return




@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in valid_users and valid_users[username] == password:
            session['username'] = username
            if username == 'a':
                return redirect(url_for('main_menu'))
            elif username == 'b':
                return redirect(url_for('display_license_data'))
        else:
            return 'Invalid login', 401
    return render_template('login.html')

@app.route('/main_menu')
def main_menu():
    if 'username' in session and session['username'] == 'a':
        return render_template('main_menu.html', username=session['username'])
    abort(401)


@app.route('/display_license_data', methods=['GET', 'POST'])
def display_license_data():
    if 'username' in session and session['username'] == 'b':
        file_path = 'license_plate_data.txt'
        search_query = request.form.get('search', '') if request.method == 'POST' else ''
        data = ""
        try:
            with open(file_path, 'r') as file:
                lines = file.readlines()
                if search_query:
                    lines = [line for line in lines if search_query in line]
                data = ''.join(lines)
        except FileNotFoundError:
            data = "File not found."
        except Exception as e:
            data = str(e)

        return render_template('display_license_data.html', data=data, search_query=search_query)
    abort(401)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/run_system', methods=['POST'])
def run_system():
    if 'username' not in session or session['username'] != 'a':
        return redirect(url_for('login'))

    choice = request.form['choice']

    if choice == '1':
        video_link = request.form.get('videoLink', '')
        speed_limit = request.form.get('speedLimit', 80)  # Default to 80 if not provided
        # Placeholder for your tracking function
        result = trackCars(video_link, int(speed_limit))  # Assuming trackCars function exists
        return render_template('result.html', result=result)
    elif choice == '2':
        cascade_path = cv2.data.haarcascades + 'haarcascade_russian_plate_number.xml'
        # Placeholder for your LicensePlateDetector class
        detector = LicensePlateDetector(cascade_path)  # Assuming LicensePlateDetector class exists
        input_folder = 'data'
        output_file = 'license_plate_data.txt'

        with open(output_file, 'w') as f:
            for filename in os.listdir(input_folder):
                if filename.endswith(('.jpg', '.jpeg', '.png')):
                    image_path = os.path.join(input_folder, filename)
                    plate_text = detector.detect_from_image(image_path)
                    if plate_text:
                        f.write(f"Image: {filename}, {plate_text}\n")

        with open(output_file, 'r') as f:
            data = f.read()

        return render_template('result.html', result=data)
    else:
        return "Invalid choice"

if __name__ == '__main__':
    app.run(debug=True)
